def calc_add(a, b):
    return a + b


def calc_multiply(a, b):
    return a * b


def exception():
    raise SystemExit(1)
    # raise SystemError

